## 编程伴侣（HBuilderX插件）

### 作者：ezshine

> 此插件的创意来源是[VSCode的彩虹屁](https://github.com/SaekiRaku/vscode-rainbow-fart)插件(感谢感谢)
> 兼容彩虹屁插件的语音包。在本插件中，播放音频采用系统自带的命令，无需打开浏览器。

### 插件使用交流Q群：1059850921
### 目前的问题，windows下请确保HBuilderX的路径中没有空格

#### 已实现功能

- 彩虹老婆

	~~~~
	## 注意注意，她真的来了！
	## 球球各位给个五星好评可以么！
	~~~~

	彩虹老婆使用说明：
		1、彩虹老婆默认是关闭的。安装插件后要在插件配置中开启才可以使用。
		2、在下载彩虹老婆容器的项目仓库中，为大家精选了多款老婆数据，请自行查阅彩虹老婆项目仓库。
		3、默认版的彩虹老婆liang以及default彩虹屁数据包经过修改，所以才可以将语音和老婆动作关联起来。
  
- 程序员鼓励师

  ~~~~
  会根据你编写的代码进行播放鼓励语音，开始使用HBuilderX写写代码试试看吧。
  ~~~~

- 时间提醒

  ~~~~
  根据当前系统的时间，提醒你休息，吃饭，起来活动一下等等。
  ~~~~

- 语音包
	完美的支持彩虹屁语音包
	- Potato Game Group 糖糖 [前往](https://github.com/heixiaobai/rainbow-fart-voice-pack)
	- Red Alert [前往](https://github.com/trotsky1997/RedAlert-Voice-Pack)
	- [更多语音包](https://github.com/topics/rainbow-fart)
  
	~~~~
	语音包下载后安装位置
	MacOS
	/Applications/HBuilderX.app/Contents/HBuilderX/plugins/ezshine-codinglover/voicepackages
  
	Windows
	打开资源管理器，进入HBuilderX安装目录，进入plugins/ezshine-codinglover/voicepackages
	~~~~
  
## 未来希望扩展为不仅仅只有彩虹屁功能
## 而是一个真正的编程伴侣。

